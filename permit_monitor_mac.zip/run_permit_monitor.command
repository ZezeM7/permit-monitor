#!/bin/bash
# run_permit_monitor.command
# Double-click this to start monitoring for permit availability.
# Runs automatically in the background, checking every N hours.
# Keep this Terminal window open while monitoring.

cd "$(dirname "$0")"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   4 River Lottery — Permit Monitor           ║"
echo "║   recreation.gov · permit #234624            ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Check for config file ─────────────────────────────────────────────────────
if [ ! -f "permit_config.env" ]; then
    echo "  ❌  No config file found (permit_config.env)"
    echo ""
    echo "  Run setup_permit_monitor.command first to configure your settings."
    echo ""
    read -p "  Press Enter to close..."
    exit 1
fi

# ── Check for permit_monitor.py ───────────────────────────────────────────────
if [ ! -f "permit_monitor.py" ]; then
    echo "  ❌  permit_monitor.py not found in this folder."
    echo ""
    echo "  Make sure all files are in the same folder:"
    echo "    permit_monitor.py"
    echo "    run_permit_monitor.command"
    echo "    setup_permit_monitor.command"
    echo ""
    read -p "  Press Enter to close..."
    exit 1
fi

# ── Check Python ──────────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "  ❌  Python 3 not found. Run setup_permit_monitor.command first."
    echo ""
    read -p "  Press Enter to close..."
    exit 1
fi

# ── Load config and display summary ──────────────────────────────────────────
export $(cat permit_config.env | grep -v '^#' | xargs)

echo "  Settings loaded from permit_config.env"
echo ""
echo "  Permit:    4 River Lottery (#234624)"
echo "  Alert to:  ${ALERT_EMAIL}"
echo "  Interval:  every ${INTERVAL_HOURS} hour(s)"
if [ -n "$SEASON_START" ] || [ -n "$SEASON_END" ]; then
echo "  Season:    ${SEASON_START:-any} → ${SEASON_END:-any}"
fi
if [ -n "$KEYWORDS" ]; then
echo "  Keywords:  ${KEYWORDS}"
fi
echo ""
echo "  ▶  Starting monitor — press Ctrl+C or close this window to stop."
echo "  ── ─────────────────────────────────────────────────────────── ──"
echo ""

# ── Run the monitor ───────────────────────────────────────────────────────────
python3 permit_monitor.py --loop

echo ""
echo "  Monitor stopped."
read -p "  Press Enter to close..."
