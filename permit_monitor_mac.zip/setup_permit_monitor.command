#!/bin/bash
# setup_permit_monitor.command
# Double-click this ONCE to configure your email alert settings.
# After setup, use run_permit_monitor.command to start monitoring.

cd "$(dirname "$0")"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   4 River Lottery — Permit Monitor Setup     ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "This will save your alert settings to: permit_config.env"
echo "You only need to run this once."
echo ""

# ── Email to send alerts FROM ────────────────────────────────────────────────
read -p "  Your Gmail address (sends the alert): " SMTP_USER
echo ""

# ── Gmail App Password ───────────────────────────────────────────────────────
echo "  You need a Gmail App Password (NOT your regular password)."
echo "  To get one:"
echo "    1. Go to: https://myaccount.google.com/apppasswords"
echo "    2. Sign in, then create a new App Password (name it anything)"
echo "    3. Copy the 16-character code it gives you"
echo ""
read -s -p "  Gmail App Password (input hidden): " SMTP_PASS
echo ""
echo ""

# ── Email to receive alerts ───────────────────────────────────────────────────
read -p "  Email to RECEIVE alerts (can be same or different): " ALERT_EMAIL
echo ""

# ── Season window ─────────────────────────────────────────────────────────────
echo "  Season window — only check during this date range."
echo "  Leave blank to always check year-round."
echo ""
read -p "  Season start date (YYYY-MM-DD, or leave blank): " SEASON_START
read -p "  Season end date   (YYYY-MM-DD, or leave blank): " SEASON_END
echo ""

# ── Keywords ──────────────────────────────────────────────────────────────────
echo "  Keyword filter — only alert if ANY of these words appear on the page."
echo "  Example: Rogue,Selway,October   Leave blank to alert on any availability."
echo ""
read -p "  Keywords (comma-separated, or leave blank): " KEYWORDS
echo ""

# ── Check interval ────────────────────────────────────────────────────────────
read -p "  How often to check? (hours, default 3): " INTERVAL_INPUT
INTERVAL_HOURS="${INTERVAL_INPUT:-3}"
echo ""

# ── Write config file ─────────────────────────────────────────────────────────
cat > permit_config.env << EOF
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=${SMTP_USER}
SMTP_PASS=${SMTP_PASS}
ALERT_EMAIL=${ALERT_EMAIL}
SEASON_START=${SEASON_START}
SEASON_END=${SEASON_END}
KEYWORDS=${KEYWORDS}
INTERVAL_HOURS=${INTERVAL_HOURS}
EOF

echo "✅  Config saved to permit_config.env"
echo ""

# ── Check Python ──────────────────────────────────────────────────────────────
echo "  Checking Python..."
if command -v python3 &>/dev/null; then
    PY=$(python3 --version 2>&1)
    echo "  ✅  Found: $PY"
else
    echo "  ❌  Python 3 not found."
    echo ""
    echo "  Install it from: https://www.python.org/downloads/"
    echo "  Then re-run this setup script."
    echo ""
    read -p "  Press Enter to close..."
    exit 1
fi

# ── Install pip packages ──────────────────────────────────────────────────────
echo ""
echo "  Installing required packages (requests, beautifulsoup4)..."
python3 -m pip install --quiet requests beautifulsoup4

if [ $? -eq 0 ]; then
    echo "  ✅  Packages installed"
else
    echo "  ⚠️   Package install had issues — trying with --break-system-packages..."
    python3 -m pip install --quiet requests beautifulsoup4 --break-system-packages
fi

# ── Send test email ───────────────────────────────────────────────────────────
echo ""
read -p "  Send a test alert email now to verify everything works? (y/n): " TEST_EMAIL
if [[ "$TEST_EMAIL" =~ ^[Yy]$ ]]; then
    echo ""
    echo "  Sending test email..."
    env $(cat permit_config.env | xargs) python3 permit_monitor.py --test-email
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   Setup complete!                            ║"
echo "║                                              ║"
echo "║   Next: double-click                         ║"
echo "║   run_permit_monitor.command to start.       ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
read -p "  Press Enter to close..."
